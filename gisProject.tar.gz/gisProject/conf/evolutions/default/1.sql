# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table bus_time_prediction (
  id                        bigint auto_increment not null,
  day                       varchar(255),
  time_slot                 varchar(255),
  source                    varchar(255),
  destination               varchar(255),
  bus_number                bigint,
  source_time               bigint,
  dest_time                 bigint,
  constraint pk_bus_time_prediction primary key (id))
;




# --- !Downs

SET FOREIGN_KEY_CHECKS=0;

drop table bus_time_prediction;

SET FOREIGN_KEY_CHECKS=1;

