     var strt=-1;
     function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 1,
          center: {lat: 12.9178, lng: 77.5946}
        });
        directionsDisplay.setMap(map);

        document.getElementById('submit').addEventListener('click', function() {
          calculateAndDisplayRoute(directionsService, directionsDisplay);
        });
      }

      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        var waypts = [];
       // var checkboxArray = document.getElementById('waypoints');

        //
          var arr=["Wipro Gate, Bangalore", "Infosys, Electronics city, Bangalore",
          "26/A ELECTRONICS CITY, HOSUR ROAD, Bengaluru, Karnataka ", "Electronics City Phase 1, Electronic City, Bengaluru",
           "Konappana Agrahara, Electronic City, Bengaluru",
          "Hosa Rd, Bengaluru, Karnataka", "Electronic City Flyover, Singasandra, Bengaluru", "Kudlu_Gate", "garvebhavi palya bangalore",
           "Bommanahalli", "Roopena_Agrahar", "Silk Board, bangalore"];
          var startstop=-1;
          var i;
          for(i=0; i<12; i++)
          {
             if(document.getElementById('start').value==arr[i])
             {
                 startstop=i;
                 break;
             }
          }
          var endstop=-1;
          for(i=0; i<12; i++)
          {
              if(document.getElementById('end').value==arr[i])
              {
                 endstop=i;
                 break;
              }
          }
          console.log(startstop+" "+endstop);
        //
          //  console.log(checkboxArray.length);
        //for (var i = 0; i < checkboxArray.length; i++) {
        /*for (var i = startstop; i < endstop; i++) {
          if (checkboxArray.options[i].selected) {
            waypts.push({
              location: checkboxArray[i].value,
              stopover: true
            });
          }
        }*/

        directionsService.route({
          origin: document.getElementById('start').value,

          destination: document.getElementById('end').value,
          waypoints: waypts,

          travelMode: 'DRIVING'
        }, function(response, status) {
          if (status === 'OK') {
            directionsDisplay.setDirections(response);
            var route = response.routes[0];
            var summaryPanel = document.getElementById('directions-panel');
            summaryPanel.append = '';
            // For each route, display summary information.

            for (var i = 0; i < route.legs.length; i++) {
              var routeSegment = i + 1;
              summaryPanel.append += '<b>Route Segment: ' + routeSegment + '</b><br>';
              summaryPanel.append += route.legs[i].start_address + ' to ';
              summaryPanel.append += route.legs[i].end_address + '<br>';
              summaryPanel.append += route.legs[i].distance.text + '<br><br>';
            }
            summaryPanel.append +=  '<br>';

          } else {
            window.alert('Directions request failed due to ' + status);
          }

        });
      }

