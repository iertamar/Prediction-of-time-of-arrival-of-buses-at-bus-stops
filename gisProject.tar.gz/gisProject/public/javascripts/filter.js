var app = angular.module('MyApp', [])
        app.controller('MyController', function ($scope) {
            //This will hide the DIV by default.
            $scope.IsVisible = false;
            $scope.IsVisible1 = true;
            //console.log($scope.IsVisible);
            $scope.ShowHide = function () {
                //If DIV is visible it will be hidden and vice versa.
                $scope.IsVisible = $scope.IsVisible ? false : true;
                $scope.IsVisible1 = $scope.IsVisible1 ? false : true;
                var start = document.getElementById('start').value ;
                var end = document.getElementById('end').value ;
                var day = document.getElementById('day').value ;
                if(day=="sunday")
                  day = "monday";
               // alert(end);
                //location.href = "http://localhost:9092/analytics/infosys/silk/monday";

                //here we are changing the value of source and destination to our required form

                if(start=="Wipro Gate, Bangalore")
                  start = "Wipro Gate" ;
                if(start=="Infosys, Electronics city, Bangalore")
                  start = "Infosys" ;
                if(start=="26/A ELECTRONICS CITY, HOSUR ROAD, Bengaluru, Karnataka ")
                  start = "STATE BANK OF INDIA" ;
                if(start=="Electronics City Phase 1,Bangalore")
                  start = "Electronic City" ;
                if(start=="Konappana Agrahara, Electronic City, Bengaluru")
                  start = "Konappana Agrahara" ;
                if(start=="Hosa Rd, Bengaluru, Karnataka")
                  start = "Hosa_Road" ;
                if(start=="Electronic City Flyover, Singasandra, Bengaluru")
                  start = "Singasandra" ;
                if(start=="Kudlu_Gate")
                  start = "Kudlu_Gate" ;
                if(start=="garvebhavi palya bangalore")
                  start = "Garebhavi_Palya" ;
                if(start=="Bommanahalli")
                  start = "Bommanahalli" ;
                if(start=="Roopena_Agrahar")
                  start = "Roopena_Agrahar" ;
                if(start=="Silk Board, bangalore")
                  start = "Central Silk Board" ;



                if(end=="Wipro Gate, Bangalore")
                  end = "Wipro Gate" ;
                if(end=="Infosys, Electronics city, Bangalore")
                  end = "Infosys" ;
                if(end=="26/A ELECTRONICS CITY, HOSUR ROAD, Bengaluru, Karnataka ")
                  end = "STATE BANK OF INDIA" ;
                if(end=="Electronics City Phase 1,Bangalore")
                  end = "Electronic City" ;
                if(end=="Konappana Agrahara, Electronic City, Bengaluru")
                  end = "Konappana Agrahara" ;
                if(end=="Hosa Rd, Bengaluru, Karnataka")
                  end = "Hosa_Road" ;
                if(end=="Electronic City Flyover, Singasandra, Bengaluru")
                  end = "Singasandra" ;
                if(end=="Kudlu_Gate")
                  end = "Kudlu_Gate" ;
                if(end=="garvebhavi palya bangalore")
                  end = "Garebhavi_Palya" ;
                if(end=="Bommanahalli")
                  end = "Bommanahalli" ;
                if(end=="Roopena_Agrahar")
                  end = "Roopena_Agrahar" ;
                if(end=="Silk Board, bangalore")
                  end = "Central Silk Board" ;

                //

                                var flag1 = 0 ;
                                var flag2 = 0 ;
                                var flag3 = 0 ;
                                var flag4 = 0 ;
                                var flag5 = 0 ;


                var url="http://localhost:9092/analytics/"+start+"/"+end+"/"+day;
                $.ajax(url,
                {
                dataType:'json',
                timeout:50000,
                success:function(data,status,xhr){
               // $('#directions-panel').append(data.length);
               $('#id0').html('');
               $('#id1').html('');
               $('#id2').html('');
               $('#id3').html('');
               $('#id4').html('');
               $('#id5').html('');
                 $('#id0').append('Following buses are available from <h2>'+start+'</h2> to <h2>'+end+'</h2>');
                for(var i=0;i<data.length;i++)
                {
                  //if(i==0)
                 // alert(data[i].sourceTime);
                  var sourcehour = Math.floor(data[i].sourceTime/(60*60));
                  var sourceremaining = data[i].sourceTime%(60*60);
                  var sourcemin=Math.floor(sourceremaining/60);
                  sourceremaining = sourceremaining%60;
                  var sourcesec = sourceremaining;
                  if(sourcemin<=9)
                    sourcemin = '0'+sourcemin;
                  if(sourcehour<=9)
                    sourcehour = '0'+sourcehour;
                  if(sourcesec<=9)
                    sourcesec = '0'+ sourcesec;

                  //////////////Destination Time Conversion////////////////

                  var dhour = Math.floor(data[i].dest_time/(60*60));
                  var dremaining = data[i].dest_time%(60*60);
                  var dmin=Math.floor(dremaining/60);
                  dremaining = dremaining%60;
                  var dsec = dremaining;
                  if(dmin<=9)
                    dmin = '0'+dmin;
                  if(dhour<=9)
                    dhour = '0'+dhour;
                  if(dsec<=9)
                    dsec = '0'+ dsec;

                  ///////////////Amar code///////////////////////////////

                    if(data[i].busNumber==1)
                    {
                      if(flag1==0)
                      {
                        $('#id1').append('<p style="font-size:140%;color: blue;font-family: courier;">Bus Number : '+data[i].busNumber+'</p>');
                        flag1 = 1 ;
                      }
                      $('#id1').append('Source Time :'+sourcehour+':'+sourcemin+':'+sourcesec
                                        +'<span>&nbsp &nbsp &nbsp</span> Destination Time :'+dhour+':'+dmin+':'+dsec+'<br>');
                    }

                    else if(data[i].busNumber==2)
                    {
                      if(flag2==0)
                      {
                        $('#id2').append('<p style="font-size:140%;color: blue;font-family: courier;">Bus Number : '+data[i].busNumber+'</p>');
                        flag2 = 1 ;
                      }
                      $('#id2').append('Source Time :'+sourcehour+':'+sourcemin+':'+sourcesec
                                        +'<span>&nbsp &nbsp &nbsp</span> Destination Time :'+dhour+':'+dmin+':'+dsec+'<br>');
                    }

                    else if(data[i].busNumber==3)
                    {
                      if(flag3==0)
                      {
                        $('#id3').append('<p style="font-size:140%;color: blue;font-family: courier;">Bus Number : '+data[i].busNumber+'</p>');
                        flag3 = 1 ;
                      }
                      $('#id3').append('Source Time :'+sourcehour+':'+sourcemin+':'+sourcesec
                                        +'<span>&nbsp &nbsp &nbsp</span> Destination Time :'+dhour+':'+dmin+':'+dsec+'<br>');
                    }

                    else if(data[i].busNumber==4)
                    {
                      if(flag4==0)
                      {
                        $('#id4').append('<p style="font-size:140%;color: blue;font-family: courier;">Bus Number : '+data[i].busNumber+'</p>');
                        flag4 = 1 ;
                      }
                      $('#id4').append('Source Time :'+sourcehour+':'+sourcemin+':'+sourcesec
                                        +'<span>&nbsp &nbsp &nbsp</span> Destination Time :'+dhour+':'+dmin+':'+dsec+'<br>');
                    }

                    else if(data[i].busNumber==5)
                    {
                      if(flag5==0)
                      {
                        $('#id5').append('<p style="font-size:140%;color: blue;font-family: courier;">Bus Number : '+data[i].busNumber+'</p>');
                        flag5 = 1 ;
                      }
                      $('#id5').append('Source Time :'+sourcehour+':'+sourcemin+':'+sourcesec
                                        +'<span>&nbsp &nbsp &nbsp</span> Destination Time :'+dhour+':'+dmin+':'+dsec+'<br>');
                    }

                }


                },
                error :function(jqXhr,textStatus,errorMessage){

                }
                });


            }

        });