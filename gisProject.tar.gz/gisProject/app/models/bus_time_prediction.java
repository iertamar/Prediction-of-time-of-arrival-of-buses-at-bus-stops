package models;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="bus_time_prediction")
public class bus_time_prediction {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="id", nullable = false)
    public long id;

    @Column(name="day")
    public String day;

    @Column(name="time_slot")
    public String time_slot;

    @Column(name="source")
    public String source;

    @Column(name="destination")
    public String destination;

    @Column(name="bus_number")
    public long bus_number;

    @Column(name="source_time") //createdAt is the latest mention of the hashtag in any tweet.
    public long source_time;

    @Column(name="dest_time") //createdAt is the latest mention of the hashtag in any tweet.
    public long dest_time;

    public long getBusNumber() {
        return bus_number;
    }

    public void setBusNumber(String busNumber) {
        this.bus_number = bus_number;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTimeSlot() {
        return time_slot;
    }

    public void setTimeSlot(String timeSlot) {
        this.time_slot = time_slot;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public long getSourceTime() {
        return source_time;
    }

    public void setSourceTime(long source_time) {
        this.source_time = source_time;
    }

    public long getDestTime() {
        return dest_time;
    }

    public void setDestTime(long dest_time) {
        this.dest_time = dest_time;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String day) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }
}