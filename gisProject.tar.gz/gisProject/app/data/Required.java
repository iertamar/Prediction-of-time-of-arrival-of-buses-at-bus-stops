package data;

import com.avaje.ebean.Ebean;
import com.fasterxml.jackson.databind.JsonNode;
import data.RecentImage;
import helper.DatetimeHelper;
import helper.JsonHelper;
import models.bus_time_prediction;
import play.mvc.*;
import views.html.*;
import models.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;

public class Required {

     public static JsonNode fun(String source , String destination , String day)
     {
         System.out.println("hello1");

         //############################new code########################

         SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

         // Get the date today using Calendar object.
         Date today = Calendar.getInstance().getTime();
         // Using DateFormat format method we can create a string
        // representation of a date with the defined format.
        String reportDate[] = df.format(today).split(" ");
        String time[] = reportDate[1].split(":");
        int range_time1 = Integer.parseInt(time[0])*60*60 + Integer.parseInt(time[1])*60+Integer.parseInt(time[2]) ;
        int range_time2 = range_time1 + 30*60;
        long r1 = range_time1 ;
        long r2 = range_time2 ;
        // Print what date is today!
        //System.out.println("Report Date: " + reportDate);
         //System.out.println("before");
        //System.out.println(range_time1+" its range "+range_time2);

         //##############################################################

         List<bus_time_prediction> bus_list = Ebean.find(bus_time_prediction.class).where().
                 eq("source" , source).eq("destination" , destination).
                 eq("day" , day).
                 le("source_time" , r2).
                 ge("source_time" , r1).
                 findList();

         //System.out.println(bus_list);
         List<RequiredAggregate>  requiredAggregates = new ArrayList<>();
         for(bus_time_prediction bus : bus_list)
         {
            // System.out.println("hello  "+bus.getSourceTime());
             requiredAggregates.add(new RequiredAggregate(bus.getBusNumber() , bus.getSourceTime() , bus.getDestTime()));
         }
         return JsonHelper.jsonify(requiredAggregates);

     }
    /*public static void fun()
    {
        //System.out.println(day);
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

        // Get the date today using Calendar object.
        Date today = Calendar.getInstance().getTime();
        // Using DateFormat format method we can create a string
        // representation of a date with the defined format.
        String reportDate[] = df.format(today).split(" ");
        String time[] = reportDate[1].split(":");
        long range_time1 = Integer.parseInt(time[0])*60*60 + Integer.parseInt(time[1])*60+Integer.parseInt(time[2]) ;
        long range_time2 = range_time1 + 30*60;
        // Print what date is today!
        //System.out.println("Report Date: " + reportDate);

        System.out.println(range_time1+" "+range_time2);
        //String source_time = new Date();
        /*List<bus_time_prediction> bus_list = Ebean.find(bus_time_prediction.class).where().
                eq("source" , source).eq("destination" , destination).
                eq("day" , day).findList();
        //System.out.println(bus_list);
        List<RequiredAggregate>  requiredAggregates = new ArrayList<>();
        for(bus_time_prediction bus : bus_list)
        {
            System.out.println(bus.getSourceTime());
            requiredAggregates.add(new RequiredAggregate(bus.getBusNumber() , bus.getSourceTime() , bus.getDestTime()));
        }
        //return JsonHelper.jsonify(requiredAggregates);

    }
     public static void main(String[] args)
     {
         fun();
     }*/
}
