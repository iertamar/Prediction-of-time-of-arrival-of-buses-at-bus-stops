package data;

import java.util.Date;

public class RequiredAggregate {
    long bus_number;
    long source_time;
    long dest_time;

    RequiredAggregate(long bus_number, long source_time, long dest_time) {
        //System.out.println("%t", dest_time);
        this.bus_number = bus_number;
        this.source_time = source_time;
        this.dest_time = dest_time;
    }

    public long getBusNumber() {
        return bus_number;
    }

    public void setBusNumber(long bus_number) {
        this.bus_number = bus_number;
    }

    public long getSourceTime() {
        return source_time;
    }

    public void setSourceTime(long source_time) {
        this.source_time = source_time;
    }

    public long getDest_time() {
        return dest_time;
    }

    public void setDestTime(long dest_time) {
        this.dest_time = dest_time;
    }
}
