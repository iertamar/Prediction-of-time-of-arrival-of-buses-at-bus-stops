package controllers;

import com.avaje.ebean.Ebean;
import data.RecentImage;
import data.Required;
import helper.DatetimeHelper;
import models.bus_time_prediction;
import play.mvc.*;

import views.html.main;
import views.html.index ;
import views.html.gisViews.*;

import java.io.IOException;
import java.util.List;

public class Application extends Controller {

    public static Result index() {
        return ok(index.render("Your new application is ready."));
    }

    public static Result doAnalysis(String source , String destination , String day) throws IOException, InterruptedException, ClassNotFoundException {
        if(Required.fun(source , destination ,day)!=null)
        {
            return ok(Required.fun(source , destination , day));
        }
        else
            return notFound("not found");
    }

}
