package helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonHelper {
    public static <T> JsonNode jsonify(T a)

    {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.valueToTree(a);
    }
}
