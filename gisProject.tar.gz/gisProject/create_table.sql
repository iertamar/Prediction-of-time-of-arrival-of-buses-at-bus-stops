create table bus_time_prediction (
  id                        bigint auto_increment not null,
 bus_number                 bigint,
  day                      varchar(255),
  source                   varchar(255),
  destination              varchar(255),
  source_time              bigint ,
  dest_time                bigint ,
  time_slot                varchar(255) ,
  constraint pk_Image_Recognition primary key (id))
;