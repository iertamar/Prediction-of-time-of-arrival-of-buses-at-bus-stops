import java.io.*;
import java.util.Scanner;

public class testing_avg {
    public static void main(String args[]) throws IOException{
        try
        {
            FileReader fr1=new FileReader("/home/amar/Desktop/project/GIS/New_Plot/9--10/bus-2**22_july_j1.csv");
            BufferedReader br1=new BufferedReader(fr1);

            FileReader fr2=new FileReader("/home/amar/Desktop/project/GIS/New_Plot/9--10/bus-3**22_july_j1.csv");
            BufferedReader br2=new BufferedReader(fr2);

            String lines1="" , lines2="" ,lines3="" ;
            String a1[];
            String a2[];
            String a3[];

            br1.readLine();br2.readLine();

            FileWriter fw = new FileWriter("/home/amar/Desktop/project/GIS/New_Plot/9--10/test_avg.csv");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE,stop_name,stop_Latitude,stop_Longitude,Distance,id");

            for(int i = 0; i<12 ; i++)
            {
                lines1 = br1.readLine();
                a1 = lines1.split(",");
                lines2 = br2.readLine();
                a2 = lines2.split(",");


                double avg_dist = ((Double.parseDouble(a1[7]) + Double.parseDouble(a2[7]))/2) ;
                String avg_time = calculateAverageOfTime(a1[3] , a2[3]) ;
                System.out.println(avg_time);
                a1[7] = Double.toString(avg_dist);
                a1[3] = avg_time;

                String temp = "";
                for(int j = 0 ; j<a1.length ; j++)
                {
                    if(j==a1.length-1 )
                        temp = temp  + a1[j];
                    else
                        temp = temp  + a1[j] + ",";
                }

                bw.newLine();
                bw.write(temp);
                bw.flush();

            }
            System.out.println("Average has been updated . Successfully ! ");
        }
        catch(FileNotFoundException e)
        {
            System.out.println("++++");
        }
    }

    public static String calculateAverageOfTime(String x , String y)
    {
        String[] splitx = x.split(" ");
        String[] splity = y.split(" ");
        //String[] splitz = z.split(" ");
        String split[] = new String[2];
        split[0] = splitx[1];
        split[1] = splity[1];
        //split[2] = splity[1];
        for(int i = 0; i<2 ; i++)
            System.out.print(split[i]+" ");
        System.out.println();
        int hh = 0,mm = 0,ss = 0;
        String temp = "";
        String ta[] ;
        int ts = 0;
        for(int i = 0; i<2 ; i++)
        {
            temp = split[i];
            ta = temp.split(":");
            ts = ts + Integer.valueOf(ta[2]) + Integer.valueOf(ta[1])*60 + Integer.valueOf(ta[0])*60*60 ;
        }
        ts = ts/split.length ;
        hh = ts/60 ;
/*	ts = ts - hh*3600 ;
        mm = ts/60 ;
        ts = ts - mm*60 ;
        ss = ts ;
*/
        String hms = String.format("%02d", hh);
        return hms ;
    }
}
