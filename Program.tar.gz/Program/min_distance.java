import java.io.*;
import java.util.Scanner;



public class min_distance {
    public static void main(String args[]) throws IOException{
     try
     {
         int r1 = 8281;
         int r2 = 12145 ;
         String lines="";
         String unparsedFile="";
         int bus_number = 3 ;
         int date = 22 ;
         String myArray[];
         FileReader fr=new FileReader("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/kk"+date+"_july@.csv");
         BufferedReader br=new BufferedReader(fr);
         br.readLine();// It is for columns name
         String arr[][] = new String[12][3];
         for(int i = 0; i<12 ; i++)
         {
             for (int j = 0 ; j<3; j++)
             {
                 arr[i][j] = "9999.99";   // Initialization
             }
         }
         for(int i = 1; i<=r1-1; i++)
             br.readLine();
         while(1==1)
         {
             lines = br.readLine();
             myArray = lines.split(",");
             int range = Integer.parseInt(myArray[8]);
             if(range>=r1 && range<=r2)
             {
                 range = (range%12 + 11)%12;
                 if(Double.parseDouble(arr[range][2]) > Double.parseDouble(myArray[7]))
                 {
                     arr[range][0] = myArray[8];
                     arr[range][1] = myArray[4];
                     arr[range][2] = myArray[7] ;
                 }
             }
             else
             {
                 break;
             }
         }

         /*for (int i = 0; i<12; i++)
         {
             for(int j = 0; j<3; j++)
             {
                 System.out.print(arr[i][j]);
             }
             System.out.println();
         }*/


         FileWriter fw = new FileWriter("/home/amar/Desktop/project/GIS/New_Plot/9--10/bus-"+bus_number+"**"+date+"_july_j1.csv");
         BufferedWriter bw = new BufferedWriter(fw);
         bw.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE,stop_name,stop_Latitude,stop_Longitude,Distance(Km),id");
         for (int i = 0; i<12; i++)
         {
             int x = Integer.parseInt(arr[i][0]);
             fr.close();
             br.close();
             fr=new FileReader("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/kk"+date+"_july@.csv");
             br=new BufferedReader(fr);
             br.readLine();
             for(int k = 1; k<=r1-1; k++)
                 br.readLine();
             for(int j = r1; j<=r2; j++)
             {

                 lines = br.readLine();
                 //System.out.println();
                 myArray = lines.split(",");
                 int range = Integer.parseInt(myArray[8]);
                 if(x==range)
                 {
                     bw.newLine();
                     bw.write(lines);
                     bw.flush();
                     break;
                 }

             }
         }
         System.out.println("Data has been transfered successfully ! ");

     }
     catch(FileNotFoundException e)
     {
         System.out.println("++++");
     }
    }
}

