import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class Main
{
    public static int findTime(String str)
    {
        String[] dtime = str.split(" ");
        String[] time = dtime[1].split(":");
        return Integer.parseInt(time[0])*60*60 + Integer.parseInt(time[1])*60 + Integer.parseInt(time[2]);
        //return (((str.charAt(11)-'0')*10 + (str.charAt(12)-'0'))*60*60 + ((str.charAt(14)-'0')*10 + (str.charAt(15)-'0'))*60 + ((str.charAt(17)-'0')*10 + (str.charAt(18)-'0')));
    }
    public static void fun(String old_add, String new_add)
    {
        ArrayList<Sorting> list = new ArrayList<Sorting>();
        FileInputStream fis_bus = null;
        Scanner scan_bus = null;
        FileOutputStream fw = null;
        PrintStream pw = null;
        int count=0;
        try
        {
            fis_bus = new FileInputStream(old_add);
            scan_bus = new Scanner(fis_bus);
            fw = new FileOutputStream(new_add);
            pw = new PrintStream(fw);
            String s = scan_bus.nextLine();
            pw.println(s+",Distance"+",ID");
            while(scan_bus.hasNextLine())
            {

                String Device_id = "";
                String LAT_DEGREE = "";
                String LONGITUDE = "";
                String IST_DATE = "";
                int minute=0;
                String Bus_stop_name = "";
                String Latitude = "";
                String Longitude = "";
                double distance = 0.0;
                int id=0;
                s= scan_bus.nextLine();
                String str[] = s.split(",");
                Device_id = str[0];
                LAT_DEGREE = str[1];
                LONGITUDE = str[2];
                IST_DATE = str[3];
                System.out.println(str[3]);
                minute = findTime(str[3]);
                System.out.println("hello");
                Bus_stop_name = str[4];
                Latitude = str[5];
                Longitude = str[6];
                //Distance d = new Distance();
                distance = Distance.distance(Double.parseDouble(LAT_DEGREE), Double.parseDouble(LONGITUDE), Double.parseDouble(Latitude), Double.parseDouble(Longitude),"k");
                //id = ++count;
                list.add(new Sorting(Device_id, LAT_DEGREE, LONGITUDE, IST_DATE, minute,
                        Bus_stop_name, Latitude, Longitude,distance, id));

            }
            Collections.sort(list);
            for(int i=0; i<list.size(); i++)
                list.get(i).id=i+1;
            for(int i=0; i<list.size(); i++)
            {
                System.out.println(list.get(i).Device_id+","+list.get(i).LAT_DEGREE+","+
                        list.get(i).LONGITUDE+","+list.get(i).IST_DATE+","+
                        list.get(i).Bus_stop_name+","+list.get(i).Latitude+","+
                        list.get(i).Longitude+","+
                        list.get(i).distance+","+list.get(i).id);
                pw.println(list.get(i).Device_id+","+list.get(i).LAT_DEGREE+","+
                        list.get(i).LONGITUDE+","+list.get(i).IST_DATE+","+
                        list.get(i).Bus_stop_name+","+list.get(i).Latitude+","+
                        list.get(i).Longitude+","+
                        list.get(i).distance+","+list.get(i).id);
                //System.out.println(list.get(i).Device_id+","+list.get(i).+","+list.get(i).IST_DATE+","+list.get(i).IST_DATE+","+list.get(i).IST_DATE+","+list.get(i).IST_DATE+","+list.get(i).IST_DATE+","+list.get(i).IST_DATE+","+list.get(i).IST_DATE+","+list.get(i).IST_DATE+","+);//+" "+list.get(i)+" "+list.get(2)+" "+list.get(3)+" "+list.get(4)+" "+list.get(5)+" "+list.get(6)+" "+list.get(7)+" "+list.get(8)+" "+list.get(9));
            }
        }
        catch (Exception e)
        {
            System.out.println("file not found");
        }
    }
    public static void main(String[] arr)
    {
        fun("/home/aman/Desktop/GIS/Bus_data/2/kk1_july@.csv", "/home/aman/Desktop/GIS/Bus_data/2/k1_july@.csv");
    }
}
