import java.io.*;
import java.util.Scanner;

public class Average {
    public static void busAverage(String path)
    {
        File fr = new File(path);
        String s[] = fr.list();
        FileInputStream finaladd = null;
        FileOutputStream fos = null;
        PrintStream prnt = null;
        for(int i=0; i<s.length; i++)
        {
            String cpath = path+"/"+s[i];
            File interval = new File(cpath);
            String[] intervaladd = interval.list();
            int[][] table = new int[interval.list().length][12];
            File average=null;
            if(intervaladd.length>0)
            {
                try {
                    average = new File(cpath+"/Average.csv");
                    prnt = new PrintStream(average);
                    average.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            int[] data = new int[12];
            for(int j=0; j<intervaladd.length; j++)
            {
                String finalpath = cpath+"/"+intervaladd[j];
                System.out.println(cpath+"    "+finalpath);

                try {
                    finaladd = new FileInputStream(finalpath);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                Scanner sc = new Scanner(finaladd);
                int column=0;
                if(sc.hasNextLine())
                   sc.nextLine();
                while(sc.hasNextLine())
                {
                    String str[] = sc.nextLine().split(",");
                    System.out.println(str[3]);
                    String divide[] = str[3].split(" ");
                    System.out.println(divide[1]);
                    String t[] = divide[1].split(":");
                    table[j][column++] = Integer.parseInt(t[0])*60 + Integer.parseInt(t[1]);
                    System.out.println(table[j][column-1]);
                }
                for(int l=1; l<12; l++)
                {
                    table[j][l] = table[j][l] - table[j][0];
                }
                table[j][0]=0;
            }
            if(intervaladd.length>0)
            {
                String[] stop_name = {"Wipro Gate", "Infosys", "STATE BANK OF INDIA", "Electronic City", "Konappana Agrahara",
                                       "Hosa_Road", "Singasandra", "Kudlu_Gate", "Garebhavi_Palya", "Bommanahalli",
                                       "Roopena_Agrahar", "Central Silk Board"};
                String[] stop_Lat = {"12.83791127", "12.84554523", "12.8455016811", "12.8475345", "12.8548020311", "12.86915506",
                                     "12.87731323", "12.88955751", "12.8961563477", "12.90483535", "12.9116731076", "12.9165109154"};
                String[] stop_long = {"77.65832738", "77.66334325", "77.6653715868", "77.67071245", "77.6650205534", "77.65373807",
                                      "77.64698748", "77.63946849", "77.6354038285", "77.63007568", "77.6258354692", "77.6210663884"};
                prnt.println("Stop Name,Stop Lat,Stop Long, Time(in minute)");
                for(int row=0; row<12; row++)
                {
                    int sum=0;
                    for(int no_of_jorney=0; no_of_jorney<intervaladd.length; no_of_jorney++)
                    {
                        sum = sum + table[no_of_jorney][row];
                    }
                    data[row] = sum / intervaladd.length;
                    prnt.println(stop_name[row]+","+stop_Lat[row]+","+stop_long[row]+","+data[row]);
                }
            }
        }
    }
    public static void main(String[] arr)
    {
        busAverage("/home/amar/Desktop/project/GIS/slots/wednesday/training");
    }
}
