import java.util.ArrayList;
import java.io.*;
import java.util.*;
public class Sorting implements Comparable<Sorting>{
    String Device_id = "";
    String LAT_DEGREE = "";
    String LONGITUDE = "";
    String IST_DATE = "";
    int minute=0;
    String Bus_stop_name = "";
    String Latitude = "";
    String Longitude = "";
    double distance = 0.0;
    int id=0;
    Sorting(String Device_id, String LAT_DEGREE, String LONGITUDE, String IST_DATE, int minute
            , String Bus_stop_name, String Latitude, String Longitude, double distance, int id)
    {
        this.Device_id = Device_id;
        this.LAT_DEGREE = LAT_DEGREE;
        this.LONGITUDE = LONGITUDE;
        this.IST_DATE = IST_DATE;
        this.minute=minute;
        this.Bus_stop_name = Bus_stop_name;
        this.Latitude = Latitude;
        this.Longitude = Longitude;
        this.distance = distance;
        this.id=id;
    }
    public int getMinute()
    {
        return minute;
    }
    public int compareTo(Sorting s)
    {
        if(minute==s.minute)
            return 0;
        else if(minute>s.minute)
            return 1;
        else
            return -1;
    }
}
