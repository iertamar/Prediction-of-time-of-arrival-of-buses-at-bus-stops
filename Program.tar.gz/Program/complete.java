import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class complete {
    public static void main(String[] args) {
        try
        {

            int tr1 = 5 ;
            int tr2 = 7 ;
            int total_intervals = 4 ;
            int total_entries_in_file = 2 ;
            for(int i = 0; i<total_intervals;i++)
            {
                FileReader fr1 = new FileReader("/home/amar/Desktop/project/GIS/index_file/1111.csv");
                BufferedReader br1 = new BufferedReader(fr1);
                br1.readLine();// It is for columns name

                for (int j = 0; j<total_entries_in_file ; j++)
                {
                    String lines = br1.readLine();
                    String arr[] = lines.split(",");
                    String arr3 = arr[3].substring(0,2);
                    //System.out.println(arr3);
                    String arr4 = arr[4].substring(0,2);
                    int bus_number = Integer.parseInt(arr[0]);
                    String ts[] = arr[2].split("-");
                    int date = Integer.parseInt(ts[2]) ;
                    int ar3 = Integer.parseInt(arr3);
                    int ar4 = Integer.parseInt(arr4);
                    String journey = arr[1] ;
                    System.out.println("hello");
                    System.out.println(ar3 +"  "+tr1 +" "+ar4+" "+tr2);
                    if(tr1>=ar3 && ar3<=tr1 && tr1>=ar4 && ar4<=tr2)
                    {
                        System.out.println("how r u");
                        System.out.println(tr1);
                        int id1 = Integer.parseInt(arr[5]);
                        int id2 = Integer.parseInt(arr[6]);
                        min_distance(id1 , id2 , bus_number , date , tr1 , journey);
                    }
                }
                tr1 = tr1 + 2 ;
                tr2 = tr2 + 2 ;
            }

        }
        catch(Exception e)
        {
            System.out.println("Exceptions occur while reading from index_file ");
        }
    }
    public static void min_distance(int id1 , int id2 ,int bus_number , int date , int slot_start , String joruney)
    {
        try
        {
            int r1 = id1;
            int r2 = id2;
            String lines="";
            //String unparsedFile="";
            //int bus_number = 3 ;
            //int date = 22 ;
            String myArray[];
            //System.out.println("before  " +date);
            FileReader fr=new FileReader("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/kk"+date+"_july@.csv");
            //System.out.println("after");
            BufferedReader br=new BufferedReader(fr);
            br.readLine();    // It is for columns name
            String arr[][] = new String[12][3];
            for(int i = 0; i<12 ; i++)
            {
                for (int j = 0 ; j<3; j++)
                {
                    arr[i][j] = "9999.99";   // Initialization
                }
            }
            for(int i = 1; i<=r1-1; i++)
                br.readLine();
            while(1==1)
            {
                lines = br.readLine();
                myArray = lines.split(",");
                int range = Integer.parseInt(myArray[8]);
                if(range>=r1 && range<=r2)
                {
                    range = (range%12 + 11)%12;
                    if(Double.parseDouble(arr[range][2]) > Double.parseDouble(myArray[7]))
                    {
                        arr[range][0] = myArray[8];
                        arr[range][1] = myArray[4];
                        arr[range][2] = myArray[7] ;
                    }
                }
                else
                {
                    break ;
                }
            }

         /*for (int i = 0; i<12; i++)
         {
             for(int j = 0; j<3; j++)
             {
                 System.out.print(arr[i][j]);
             }
             System.out.println();
         }*/

            System.out.println(slot_start+"kkkk");
            FileWriter fw = new FileWriter("/home/amar/Desktop/project/GIS/slots/"+slot_start+"-"+(slot_start+2)+"/"+bus_number+" kk"+date+"_july@_"+joruney+".csv");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE,stop_name,stop_Latitude,stop_Longitude,Distance(Km),id");

            for (int i = 0; i<12; i++)
            {
                int x = Integer.parseInt(arr[i][0]);
                fr.close();
                br.close();
                fr = new FileReader("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/kk"+date+"_july@.csv");
                br=new BufferedReader(fr);
                br.readLine();
                for(int k = 1; k<=r1-1; k++)
                    br.readLine();
                for(int j = r1; j<=r2; j++)
                {

                    lines = br.readLine();
                    //System.out.println();
                    myArray = lines.split(",");
                    int range = Integer.parseInt(myArray[8]);
                    if(x==range)
                    {
                        bw.newLine();
                        bw.write(lines);
                        bw.flush();
                        break;
                    }

                }
            }
            System.out.println("Data has been transfered successfully ! ");

        }
        catch (Exception e)
        {
            System.out.println("Error while finding min_distance ");
        }
    }
}
