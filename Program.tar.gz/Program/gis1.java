import java.io.*;
import java.util.Scanner;



public class gis1 {
    public static void main(String args[]) throws IOException{
        try {
            String lines = "";
            String myArray[];
            String bus_number = "8";
            int r = 59920 ;

            FileReader fr = new FileReader("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/required.csv");
            BufferedReader br = new BufferedReader(fr);

            FileWriter fw1 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/1_july.csv");
            BufferedWriter bw1 = new BufferedWriter(fw1);
            bw1.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw2 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/2_july.csv");
            BufferedWriter bw2 = new BufferedWriter(fw2);
            bw2.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw3 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/3_july.csv");
            BufferedWriter bw3 = new BufferedWriter(fw3);
            bw3.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw4 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/4_july.csv");
            BufferedWriter bw4 = new BufferedWriter(fw4);
            bw4.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw5 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/5_july.csv");
            BufferedWriter bw5 = new BufferedWriter(fw5);
            bw5.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw6 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/6_july.csv");
            BufferedWriter bw6 = new BufferedWriter(fw6);
            bw6.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw7 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/7_july.csv");
            BufferedWriter bw7 = new BufferedWriter(fw7);
            bw7.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw8 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/8_july.csv");
            BufferedWriter bw8 = new BufferedWriter(fw8);
            bw8.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw9 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/9_july.csv");
            BufferedWriter bw9 = new BufferedWriter(fw9);
            bw9.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw10 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/10_july.csv");
            BufferedWriter bw10 = new BufferedWriter(fw10);
            bw10.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw11 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/11_july.csv");
            BufferedWriter bw11 = new BufferedWriter(fw11);
            bw11.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw12 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/12_july.csv");
            BufferedWriter bw12 = new BufferedWriter(fw12);
            bw12.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw13 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/13_july.csv");
            BufferedWriter bw13 = new BufferedWriter(fw13);
            bw13.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw14 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/14_july.csv");
            BufferedWriter bw14 = new BufferedWriter(fw14);
            bw14.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw15 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/15_july.csv");
            BufferedWriter bw15 = new BufferedWriter(fw15);
            bw15.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw16 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/16_july.csv");
            BufferedWriter bw16 = new BufferedWriter(fw16);
            bw16.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw17 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/17_july.csv");
            BufferedWriter bw17 = new BufferedWriter(fw17);
            bw17.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");


            FileWriter fw18 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/18_july.csv");
            BufferedWriter bw18 = new BufferedWriter(fw18);
            bw18.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw19 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/19_july.csv");
            BufferedWriter bw19 = new BufferedWriter(fw19);
            bw19.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw20 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/20_july.csv");
            BufferedWriter bw20 = new BufferedWriter(fw20);
            bw20.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw21 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/21_july.csv");
            BufferedWriter bw21 = new BufferedWriter(fw21);
            bw21.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw22 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/22_july.csv");
            BufferedWriter bw22 = new BufferedWriter(fw22);
            bw22.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw23 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/23_july.csv");
            BufferedWriter bw23 = new BufferedWriter(fw23);
            bw23.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw24 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/24_july.csv");
            BufferedWriter bw24 = new BufferedWriter(fw24);
            bw24.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw25 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/25_july.csv");
            BufferedWriter bw25 = new BufferedWriter(fw25);
            bw25.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw26 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/26_july.csv");
            BufferedWriter bw26 = new BufferedWriter(fw26);
            bw26.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw27 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/27_july.csv");
            BufferedWriter bw27 = new BufferedWriter(fw27);
            bw27.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw28 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/28_july.csv");
            BufferedWriter bw28 = new BufferedWriter(fw28);
            bw28.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw29 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/29_july.csv");
            BufferedWriter bw29 = new BufferedWriter(fw29);
            bw29.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw30 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/30_july.csv");
            BufferedWriter bw30 = new BufferedWriter(fw30);
            bw30.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");

            FileWriter fw31 = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/"+bus_number+"/31_july.csv");
            BufferedWriter bw31 = new BufferedWriter(fw31);
            bw31.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE");


            br.readLine();// It is for columns name
            for(int i = 0; i< r ; i++)
            {
                lines = br.readLine();
                myArray = lines.split(",");
                String arr1[];
                arr1 = myArray[3].split(" ");;
                String arr2[];
                arr2 = arr1[0].split("-");
                int year = Integer.parseInt(arr2[0]) ;
                int month = Integer.parseInt(arr2[1]) ;
                int day = Integer.parseInt(arr2[2]) ;
                if(day==1 && month==7 && year==2016)
                {
                    bw1.newLine();
                    bw1.write(lines);
                    bw1.flush();
                }
                if(day==2 && month==7 && year==2016)
                {
                    bw2.newLine();
                    bw2.write(lines);
                    bw2.flush();
                }
                if(day==3 && month==7 && year==2016)
                {
                    bw3.newLine();
                    bw3.write(lines);
                    bw3.flush();
                }
                if(day==4 && month==7 && year==2016)
                {
                    bw4.newLine();
                    bw4.write(lines);
                    bw4.flush();
                }
                if(day==5 && month==7 && year==2016)
                {
                    bw5.newLine();
                    bw5.write(lines);
                    bw5.flush();
                }if(day==6 && month==7 && year==2016)
            {
                bw6.newLine();
                bw6.write(lines);
                bw6.flush();
            }if(day==7 && month==7 && year==2016)
            {
                bw7.newLine();
                bw7.write(lines);
                bw7.flush();
            }if(day==8 && month==7 && year==2016)
            {
                bw8.newLine();
                bw8.write(lines);
                bw8.flush();
            }if(day==9 && month==7 && year==2016)
            {
                bw9.newLine();
                bw9.write(lines);
                bw9.flush();
            }if(day==10 && month==7 && year==2016)
            {
                bw10.newLine();
                bw10.write(lines);
                bw10.flush();
            }if(day==11 && month==7 && year==2016)
            {
                bw11.newLine();
                bw11.write(lines);
                bw11.flush();
            }if(day==12 && month==7 && year==2016)
            {
                bw12.newLine();
                bw12.write(lines);
                bw12.flush();
            }if(day==13 && month==7 && year==2016)
            {
                bw13.newLine();
                bw13.write(lines);
                bw13.flush();
            }
                if(day==14 && month==7 && year==2016)
                {
                    bw14.newLine();
                    bw14.write(lines);
                    bw14.flush();
                }
                if(day==15 && month==7 && year==2016)
                {
                    bw15.newLine();
                    bw15.write(lines);
                    bw15.flush();
                }if(day==16 && month==7 && year==2016)
            {
                bw16.newLine();
                bw16.write(lines);
                bw16.flush();
            }if(day==17 && month==7 && year==2016)
            {
                bw17.newLine();
                bw17.write(lines);
                bw17.flush();
            }if(day==18 && month==7 && year==2016)
            {
                bw18.newLine();
                bw18.write(lines);
                bw18.flush();
            }if(day==19 && month==7 && year==2016)
            {
                bw19.newLine();
                bw19.write(lines);
                bw19.flush();
            }
                if(day==20 && month==7 && year==2016)
                {
                    bw20.newLine();
                    bw20.write(lines);
                    bw20.flush();
                }
                if(day==21 && month==7 && year==2016)
                {
                    bw21.newLine();
                    bw21.write(lines);
                    bw21.flush();
                }
                if(day==22 && month==7 && year==2016)
                {
                    bw22.newLine();
                    bw22.write(lines);
                    bw22.flush();
                }
                if(day==23 && month==7 && year==2016)
                {
                    bw23.newLine();
                    bw23.write(lines);
                    bw23.flush();
                }
                if(day==24 && month==7 && year==2016)
                {
                    bw24.newLine();
                    bw24.write(lines);
                    bw24.flush();
                }if(day==25 && month==7 && year==2016)
            {
                bw25.newLine();
                bw25.write(lines);
                bw25.flush();
            }if(day==26 && month==7 && year==2016)
            {
                bw26.newLine();
                bw26.write(lines);
                bw26.flush();
            }if(day==27 && month==7 && year==2016)
            {
                bw27.newLine();
                bw27.write(lines);
                bw27.flush();
            }if(day==28 && month==7 && year==2016)
            {
                bw28.newLine();
                bw28.write(lines);
                bw28.flush();
            }if(day==29 && month==7 && year==2016)
            {
                bw29.newLine();
                bw29.write(lines);
                bw29.flush();
            }if(day==30 && month==7 && year==2016)
            {
                bw30.newLine();
                bw30.write(lines);
                bw30.flush();
            }
                if(day==31 && month==7 && year==2016)
                {
                    bw31.newLine();
                    bw31.write(lines);
                    bw31.flush();
                }
            }

            crossProduct.fun(Integer.parseInt(bus_number));

        }
           /* FileWriter fw = new FileWriter("/home/amar/Desktop/project/GIS/plot/29_july_j4.csv");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,VEHICLE_DIRECTION,SPEED_KMPH,IST_DATE,stop_name,stop_Latitude,stop_Longitude,Distance(Km),id");
            for (int i = 0; i<12; i++)
            {
                int x = Integer.parseInt(arr[i][0]);
                fr.close();
                br.close();
                fr=new FileReader("/home/amar/Desktop/project/GIS/files/29_july.csv");
                br=new BufferedReader(fr);
                br.readLine();
                for(int k = 1; k<=r1-1; k++)
                    br.readLine();
                for(int j = r1; j<=r2; j++)
                {

                    lines = br.readLine();
                    //System.out.println();
                    myArray = lines.split(",");
                    int range = Integer.parseInt(myArray[10]);
                    if(x==range)
                    {
                        bw.newLine();
                        bw.write(lines);
                        bw.flush();
                        break;
                    }

                }
            }
            System.out.println("Data has been transfered successfully ! ");

        }*/

        catch(FileNotFoundException e)
        {
            System.out.println(e);
        }
    }
}
