import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class crossProduct {
    public static void fun(int bus_number) {
        try {
            for (int k = 1 ; k<=31 ; k++) {
                String lines1 = "", lines2 = "", lines3 = "";
                String myArray[];
                //int bus_number = 1;
                FileReader fr1 = new FileReader("/home/amar/Desktop/project/GIS/Bus_data/" + bus_number + "/" + k + "_july.csv");
                BufferedReader br1 = new BufferedReader(fr1);
                br1.readLine();// It is for columns name

                // It is for columns name

                FileWriter fw = new FileWriter("/home/amar/Desktop/project/GIS/Bus_data/" + bus_number + "/kkk" + k + "_july@.csv");
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("DEVICE_ID,LAT_DEGREE,LONGITUDE,IST_DATE,Bus_stop_name,Latitude,Longitude");

                //lines3 =
                for (int l = 0; l < 7000; l++) {
                    lines1 = br1.readLine();
                    if (lines1 == null) break;

                    FileReader fr2 = new FileReader("/home/amar/Desktop/project/GIS/Bus_data/Bus_stop.csv");
                    BufferedReader br2 = new BufferedReader(fr2);
                    br2.readLine();

                    //lines1 = br1.readLine();
                    for (int i = 0; i < 12; i++) {

                        lines2 = br2.readLine();
                        String res = lines1 + "," + lines2;
                        bw.newLine();
                        bw.write(res);
                        bw.flush();
                    }
                    //lines3 = br1.readLine() ;

                }

                //Main m = new Main();
                Main.fun("/home/amar/Desktop/project/GIS/Bus_data/" + bus_number + "/kkk" + k + "_july@.csv", "/home/amar/Desktop/project/GIS/Bus_data/" + bus_number + "/kk" + k + "_july@.csv");
                System.out.println("success");
            }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
}
